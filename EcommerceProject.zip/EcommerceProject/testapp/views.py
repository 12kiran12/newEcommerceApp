from django.shortcuts import render
from testapp.models import Product
from testapp.forms import DetailsForm
from django.http import HttpResponse

# Create your views here.
def get_product_data(request):
    product_list=Product.objects.all()

    item_name=request.GET.get('item_name')
    if item_name!='' and item_name!=None:
        product_list=product_list.filter(name__contains=item_name)
    




    my_dict={'product_list':product_list}
    return render(request,'welcome.html',my_dict)

def details(request):
    form=DetailsForm()
    my_dict={'form':form}
    return render(request,"details.html",my_dict)



def payment(request):
    if request.method=='POST':
        order_amount = 500
        order_currency = 'INR'
        #notes = {'Shipping address': 'Bommanahalli, Bangalore'}
        client=razorpay.Client(auth=('rzp_test_0dezIG4lX6DoFS','UalHp4eUTVln861tN97iYYZF'))
        client.order.create(amount=order_amount, currency=order_currency)
    #return render(request,"home.html")


def success(request):
    return render(request,'success.html')


